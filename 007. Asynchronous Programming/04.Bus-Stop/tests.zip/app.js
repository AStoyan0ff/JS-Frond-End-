function getInfo() {

    const stopIdInput = document.getElementById('stopId');
    const stopNameDiv = document.getElementById('stopName');
    const busesUl = document.getElementById('buses');

    const stopId = stopIdInput.value;

    stopNameDiv.textContent = '';
    busesUl.innerHTML = '';

    const URL = `http://localhost:3030/jsonstore/bus/businfo/${stopId}`;

    fetch(URL)
        .then(res => {

            if (!res.ok) {
                throw new Error();
            }
            return res.json();
        })
        .then(data => {
            stopNameDiv.textContent = data.name;

            for (let busId in data.buses) {

                const li = document.createElement('li');
                li.textContent = `Bus ${busId} arrives in ${data.buses[busId]} minutes`;
                busesUl.appendChild(li);
            }
        })
        .catch(() => {
            stopNameDiv.textContent = 'Error';
        });
    //console.log("TODO...");
}